# Shavit Scripts
#### Collection Of Usefull Linux Scripts 

- bu - Backup home to EXTERNAL HDD
- cheat - Cheats linux commands
- cpu_core - Show number of physical and logical code
- cya - Cover Your Ass (backup tool)
- manage_ssh - Manage ssh
- pretty_ping - Pretty ping
- ts - Timestamp files
- turn_of_monitor_p2 - Turn Off monitor - python2
- turn_of_monitor_p3 - Turn Off monitor - python3
- up - Update Debian system

